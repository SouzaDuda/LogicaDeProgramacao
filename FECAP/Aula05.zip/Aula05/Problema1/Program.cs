﻿using System.Net.Http.Headers;

double preco = 1;
double soma = 0;
double media = 0;
double qntde = 0;
Console.WriteLine("Entre com os preços coletados e 0 para terminar!");

while (preco > 0)
{
    Console.Write("Preço Coletado:");
    preco = Double.Parse(Console.ReadLine());
    if (preco > 0)
    {
        soma = soma + preco;
        qntde = qntde + 1;
    }
    Console.WriteLine("Soma Parcial: " + soma);
}
media = soma / qntde;
Console.WriteLine("Preço Médio do litro da gasolina: " +  media);