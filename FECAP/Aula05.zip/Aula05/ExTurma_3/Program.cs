﻿// Soma de 1 a 5

int num = 0;

while(num < 5)
{
    num++; // ou num = num + 1;
    Console.WriteLine(num);
}