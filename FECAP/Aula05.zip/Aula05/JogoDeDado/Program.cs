﻿//Para ganhar tem que dar 7 (+ fácil), 11 (- menos provável / + difícil) ou ambos os números iguais

using System;

/*Random rnd = new Random(); // randomiza o número
string SN = "";
int i = 0;
double wallet = 100;

while (wallet > 0 && wallet < 200)
{
    int dado1 = rnd.Next(1, 6); // Next(min, max)
    int dado2 = rnd.Next(1, 6);
    Console.WriteLine(dado1 + "|" + dado2);
    i++;
    if (dado1 == dado2 || dado1 + dado2 == 7 || dado1 + dado2 == 11)
    {
        Console.WriteLine("Você ganhou!");
        wallet = wallet + 100;
    }
    else
    {
        wallet = wallet - 100;
        Console.WriteLine("Você perdeu! Tente novamente.");
    }
    Console.WriteLine("Wallet: " + wallet);
    Console.WriteLine("Gostaria de tentar novamente?");
    SN = Console.ReadLine();
}
Console.WriteLine("Wallet Final: " + wallet); */


Random rnd = new Random();
double wallet = 100;
string sn = "";

Console.WriteLine("Bem-vindo ao Cassino de Dados!");
Console.WriteLine("Regras: Ganhe com Soma 7, 11 ou Pares Iguais.");

while (wallet > 0)
{
    Console.WriteLine("\n--- Nova Rodada ---");
    Console.WriteLine("Wallet: R$ " + wallet);
    Console.WriteLine("Gostaria de apostar R$ 100? (s/n)");
    sn = Console.ReadLine().ToLower();

    if (sn != "s")
    {
        break; // Sai do loop se o usuário não digitar 's'
    }

    // CORREÇÃO: Next(1, 7) para incluir o dado 6
    int dado1 = rnd.Next(1, 7);
    int dado2 = rnd.Next(1, 7);
    int soma = dado1 + dado2;

    Console.WriteLine($"Dados: {dado1} | {dado2} (Soma: {soma})");

    if (dado1 == dado2 || soma == 7 || soma == 11)
    {
        Console.WriteLine("🎉 Você ganhou!");
        wallet += 100;
    }
    else
    {
        Console.WriteLine("😞 Você perdeu! Tente novamente.");
        wallet -= 100;
    }
}

Console.WriteLine("\n--- Fim de Jogo ---");
Console.WriteLine("Wallet Final: R$ " + wallet);