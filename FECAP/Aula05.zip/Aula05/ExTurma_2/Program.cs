﻿// Pares até 20

int num = 0;

while (num  < 20)
{
    num += 2;
    Console.WriteLine(num);
}