﻿// Contagem Simples, escreva um algoritmo com while que mostre os números de 1 até 10.

int numero = 0;

while(numero < 10)
{
    numero = numero + 1;
    Console.WriteLine(numero);
}
