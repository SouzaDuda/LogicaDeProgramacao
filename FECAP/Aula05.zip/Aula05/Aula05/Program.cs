﻿/*int numero = 1;
int soma = 0;

while (numero <= 4)
{
    soma = numero + soma;
    numero = numero + 1;
    
}

Console.WriteLine("Soma é: " + soma);
Console.WriteLine("Número é: " + numero);*/

// Operador Lógico, Diferente: != ; Negação: !

String SN = "";
while(SN!="S" && SN != "N") // enquanto SN for diferente de S e N, para ser negação tem que ser apenas !
{
    Console.Write("Deseja continuar?(S/N):");
    SN = Console.ReadLine();
}

if (SN == "N")
{
    Console.WriteLine("Fim");
}
else
{
    Console.WriteLine("Continua . . .");
}