﻿//int num = 0;

Console.WriteLine("Quantos números você quer que seja contado?");
int num = int.Parse