﻿
int [] nota=new int[5];
/*nota[0] = 10;
nota[1] = 7;
nota[2] = 8;
nota[3] = 6;
nota[4] = 4;
nota[5] = 3;    
nota[60] = 4;*/

/*Gera uma COLEÇÃO de inteiros aleatórios*/
Random rnd=new Random();
for (int i = 0; i < nota.Length; i++)
{
    int num=rnd.Next(0,11); //Sorteio um número inteiro de 0 a 10
    nota[i]=-1*num;
}

for (int i = 0; i < nota.Length; i++)
{
    Console.WriteLine("Indice "+i+":"+nota[i]);
}
//Soma as notas e calcula a nota média
int soma = 0;
for (int i = 0; i < nota.Length; i++)
{
    soma = soma + nota[i];
}

int media=soma/nota.Length;
Console.WriteLine("Nota média da prova:"+media);

//Solução particular
int maior = 0;
for (int i = 0;i < nota.Length; i++)
{
    if (nota[i] > maior)
    {
        maior = nota[i]; 
    }
}

Console.WriteLine("Maior nota da prova:" + maior);

//Solução Geral (Qualquer Coleção de Números)
maior = nota[0];
for (int i = 1; i < nota.Length; i++)
{
    if (nota[i] > maior)
    {
        maior = nota[i];
    }
}

Console.WriteLine("Maior nota da prova:" + maior);
