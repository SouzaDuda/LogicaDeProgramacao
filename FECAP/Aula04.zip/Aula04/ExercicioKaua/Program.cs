﻿double a1, r, n, S, delta;

Console.Write("Entre com a 1º Parcela (a1):");
a1 = Double.Parse(Console.ReadLine()); // parse = converte um tipo de dado para outro para ser lido

Console.Write("Entre com o incremento de parcela (r):");
r = Double.Parse(Console.ReadLine());


Console.Write("Entre com o total acumulado (s):");
S = Double.Parse(Console.ReadLine());

delta = Math.Pow((2 * a1 - r), 2) + 8 * r * S;
if (delta < 0)
{
    Console.WriteLine("Não existe solução real.");
}
else
{
    n = (-(2 * a1 - r) + Math.Sqrt(delta)) / (2 * r);

    if (n > 0 && n == (int)n)
    {
        Console.WriteLine("Quantidade de Meses:" + n);
    }
    else
    {
        n = (int)n + 1;
        Double novaSoma = (2 * a1 + (n - 1) * r) * (n / 2);
        Console.WriteLine("Quantidade de Meses:" + n);
        Console.WriteLine("Novo Valor Total:" + novaSoma);
    }
}

