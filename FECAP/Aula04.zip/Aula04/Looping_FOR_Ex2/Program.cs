﻿using System.Runtime.Serialization;

// Ler n números e imprimir o maior

/*Console.Write("Insira o primeiro número: ");
int n1 = int.Parse(Console.ReadLine());

Console.Write("Insira o segundo número: ");
int n2 = int.Parse(Console.ReadLine());

Console.Write("Insira o terceiro número: ");
int n3 = int.Parse(Console.ReadLine());

int maior = 0;

for (int i = 1; i < n; i++)
{
    maior += 1;

}*/

Console.Write("Quantos números deseja inserir? ");
int n = int.Parse(Console.ReadLine());

if (n <= 0) return;

// Lê o primeiro número para iniciar a comparação
Console.Write("Insira o 1º (primeiro) número: ");
int n1 = int.Parse(Console.ReadLine());

// Laço para ler os números restantes
for (int i = 2; i <= n; i++)
{
    Console.Write($"Insira o {i}º número: ");
    /*int[] atual = new Array;
    int[] atual = array.Parse(Console.ReadLine());*/

    List<int> atual = new List<int>();
    List<int> atual = Console.ReadLine();

    // Verifica se o atual é maior que o armazenado
    if (atual > n1)
    {
        n1 = atual;
        Console.Write("O maior número é:" + n1);
    }
}