﻿
#region Comandos de Input

using System.Globalization;

Console.WriteLine("oii!"); // Muda de linha quando necessário o Console.Write não

#endregion

#region Trabalhando com Variáveis

String texto; // É possível criar várias variáveis em uma só linha, ex: String A, B, C;

texto = "bom dia";

String A, B, C;
A = "Fecap";
B = "2026";
C = A + B; // Concatenacao

Console.WriteLine(C);

int X, Y, Z;
X = 100;
Y = 2026;
Z = X + Y;
Console.WriteLine(Z);

#endregion

#region Comandos de Input

String Nome;
int Idade, Ano;

Console.Write("Insira o seu nome:");
Nome = Console.ReadLine(); //Apenas lê var do tipo String, tipo número da erro logo é necessário converter para int a variável

Console.Write("Insira a sua idade:");
Idade = int.Parse(Console.ReadLine());

Ano = 2026 - Idade;
Console.WriteLine(Nome + ", de " + Idade + " anos seja bem vindo(a) a FECAP");
Console.WriteLine("Você nasceu no ano, " + Ano + " ou no ano " + (Ano-1));

if(Ano < 2001)
{
    Console.WriteLine("Você é do século XX (20).");
}
else
{
    Console.WriteLine("Você é do século XXI (21).");
}
#endregion