﻿using System.Runtime.Serialization;

// Soma dos pares de um número

Console.Write("Insira um número para ser feita a soma dos números pares: ");
int n = int.Parse(Console.ReadLine());
int soma = 0;

for (int i = 2; i <= n; i += 2)
{
    soma = n + i;

}

Console.Write("O resultado é:" +  soma);