﻿
Console.WriteLine("Resolvendo o exercício 2!");
