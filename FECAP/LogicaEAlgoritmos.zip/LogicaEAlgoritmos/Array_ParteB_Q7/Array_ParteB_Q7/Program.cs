﻿
int[] num = new int[6];

for(int i = 0; i < num.Length; i++)
{
    Console.WriteLine($"Olá, insira o: {i} número:");
    num[i]= int.Parse(Console.ReadLine());
    Console.WriteLine($"Número inserido: { num[i]}.");
}

//Imprimir número ao inverso

for(int i = num.Length-1; i >= 0; i--)
{
    Console.WriteLine($"Número impresso: { num[i]}.");
}
