﻿using System.Net.Http.Headers;
using System.Runtime.Serialization;

double[] temperatura = new double[7];

double somaSemanal = 0;
double mediaSemanal = 0;

double maior = temperatura[0];
double menor = temperatura[0];

for (int i = 1; i < temperatura.Length; i++)
{
    Console.WriteLine($"Insira a temperatura do dia {i}.");
    temperatura[i] = double.Parse(Console.ReadLine());
    somaSemanal = somaSemanal + temperatura[i];

    if(maior < temperatura[i])
    {
        maior = temperatura[i];
        // Console.Write($"Maior temperatura é: {maior}.");
    }
    if(temperatura[i] < menor)
    {
        menor = temperatura[i];
        // Console.Write($"Menor temperatura é: {menor}.");
    }

    mediaSemanal = somaSemanal / temperatura.Length;

    if (temperatura[i] > mediaSemanal)
    {
        mediaSemanal = temperatura[i];
        // Console.Write($"Temperatura do dia: {temperatura[i]}, acima da média.");
    }

}

Console.Write($"Maior temperatura é: {maior}.");
Console.Write($"Menor temperatura é: {menor}.");
Console.Write($"O dia que fez: {mediaSemanal}ºC, foi acima da média.");
