﻿using System.Runtime.Serialization;

int[] notas = new int[10];
int soma = 0;
int media = 0;

for (int i = 0; i < notas.Length; i++)
{
    Console.Write($"Insira a {i} nota: ");
    notas[i] = int.Parse(Console.ReadLine());
    soma = soma + notas[i];
}

media = soma/notas.Length;
Console.WriteLine($"Soma: {soma}, Média: {media}");