﻿
using System.Numerics;

/*void PodeRepetir()
{
    string resposta = false;

    Console.WriteLine("Gostaria de inserir outro pacote? ");
    resposta = Console.ReadLine();
    if (resposta == true)
    {
        LerPeso(pesoPacote);
    }
}

Double LerPeso(Double pesoPacote)
{
    // Double pesoPacote = 0;

    Console.WriteLine("Insira o peso do pacote: ");
    pesoPacote = Double.Parse(Console.ReadLine());
    Console.WriteLine($"O peso do pacote inserido foi: {pesoPacote}");
    List<Double> pesoDosPacotes = new List<Double>();
    if(PodeRepetir)
    return pesoPacote;
}

Double CalcularMedia(Double pesoDosPacotes)
{
    
} */

// ---------------------------------------------------------------------

void LerPeso(Double[] peso)
{
    for(int i = 0;  i < peso.Length; i++)
    {
        Console.Write("Insira o peso do pacote: ");
        peso[i] = Double.Parse(Console.ReadLine());
    }
}

Double CalcularMedia(Double[] peso)
{
    Double soma = 0;

    for(int i = 0; i < peso.Length; i++)
    {
        soma += peso[i];
    }
    Double mediaPacote = soma / peso.Length;
    return mediaPacote;

    /*foreach (Double item in peso)
    {
        mediaPacote = soma / peso.Length;
    }*/

}

int QntdeAbaixo480(Double[] peso)
{
    int qntde = 0;
    for(int i = 0; i < peso.Length; i++)
    {
        if (peso[i] < 480)
        {
            qntde++; 
        }
    }
    return qntde;
}

int QntdeAcima520(Double[] peso)
{
    int qntde = 0;
    for (int i = 0; i < peso.Length; i++)
    {
        if (peso[i] > 520)
        {
            qntde++;
        }
    }
    return qntde;
}

Double PercentualErro(Double qtdeAbaixo, Double qntdeAcima, Double qtdeTotal)
{
    Double result = (qtdeAbaixo + qntdeAcima) / qtdeTotal;
    return result;
}


Double[] peso = new double[5]; // cria o vetor (lista) para armazenar os valores
LerPeso(peso); // executa o módulo

Double media = CalcularMedia(peso); // executa o modulo de calcular media e salva o valor na media
Console.WriteLine($"A média dos pacotes é: {media} "); // mostra a media no console

int QntAbaixoDe480 = QntdeAbaixo480(peso);
Console.WriteLine($"A quantidade de pacotes abaixo de 480 são: {QntAbaixoDe480}");

int QntAcimaDe520 = QntdeAcima520(peso);
Console.WriteLine($"A quantidade de pacotes abaixo de 480 são: {QntAcimaDe520}");

Double erro = PercentualErro(QntAbaixoDe480, QntAcimaDe520, peso.Length);